let awaitingJokeConfirmation = false;

function sendMessage() {
  const chatBox = document.getElementById('chatBox');
  const userInput = document.getElementById('userInput');
  const userText = userInput.value.trim();

  if (userText !== '') {
    const userMessage = document.createElement('div');
    userMessage.classList.add('message', 'user-message');
    userMessage.textContent = userText;
    chatBox.appendChild(userMessage);

    if (awaitingJokeConfirmation) {
      if (userText.toLowerCase() === 'yes') {
        fetchJoke();
        awaitingJokeConfirmation = false;
      } else if (userText.toLowerCase() === 'no') {
        showBotMessage("Thanks for chatting! 🐾");
        awaitingJokeConfirmation = false;
      } else {
        showBotMessage("Please type 'Yes' or 'No' 😺");
      }
    } else {
      showBotMessage("Hello 😺, Do you want to hear a joke? If yes, type 'Yes'");
      awaitingJokeConfirmation = true;
    }

    userInput.value = '';
    chatBox.scrollTop = chatBox.scrollHeight;
  }
}

function fetchJoke() {
  fetch("https://official-joke-api.appspot.com/random_joke")
    .then(response => response.json())
    .then(data => {
      displayJoke(data.setup + " " + data.punchline);
    });
}

function displayJoke(joke) {
  const chatBox = document.getElementById('chatBox');
  const botMessage = document.createElement('div');
  botMessage.classList.add('message', 'bot-message');

  const kittySticker = document.createElement('img');
  kittySticker.src = "https://i.imgur.com/Ow3Jj3G.png";
  kittySticker.classList.add('kitty-sticker');

  botMessage.appendChild(kittySticker);
  botMessage.appendChild(document.createTextNode(joke));
  chatBox.appendChild(botMessage);

  showRatingButtons();

  setTimeout(() => {
    showBotMessage("Hii Dear, Do you want to hear another joke? Type 'Yes' for more fun or 'No' to stop!");
    awaitingJokeConfirmation = true;
  }, 1000);

  chatBox.scrollTop = chatBox.scrollHeight;
}

function showRatingButtons() {
  const chatBox = document.getElementById('chatBox');
  const ratingContainer = document.createElement('div');
  ratingContainer.classList.add('rating-buttons');

  const ratings = [
    { text: "Bad 😞", class: "bad" },
    { text: "Not Bad 😐", class: "not-bad" },
    { text: "Good 🙂", class: "good" },
    { text: "Funny 😆", class: "funny" },
    { text: "Very Funny 😂", class: "very-funny" }
  ];

  ratings.forEach(rating => {
    const button = document.createElement('button');
    button.textContent = rating.text;
    button.classList.add(rating.class);
    button.onclick = () => handleRating(button.text);
    ratingContainer.appendChild(button);
  });

  chatBox.appendChild(ratingContainer);
  chatBox.scrollTop = chatBox.scrollHeight;
}

function handleRating(rating) {
  showBotMessage(`Thanks for your feedback: ${rating}! 🐱`);
}

function showBotMessage(message) {
  const chatBox = document.getElementById('chatBox');
  const botMessage = document.createElement('div');
  botMessage.classList.add('message', 'bot-message');

  const kittySticker = document.createElement('img');
  kittySticker.src = "https://i.imgur.com/Ow3Jj3G.png";
  kittySticker.classList.add('kitty-sticker');

  const textNode = document.createElement('span');
  botMessage.appendChild(kittySticker);
  botMessage.appendChild(textNode);
  chatBox.appendChild(botMessage);

  let index = 0;
  const typingSpeed = 30;

  const interval = setInterval(() => {
    textNode.textContent += message.charAt(index);
    index++;
    if (index >= message.length) {
      clearInterval(interval);
    }
    chatBox.scrollTop = chatBox.scrollHeight;
  }, typingSpeed);
}
function toggleInfo() {
    var popup = document.getElementById("infoPopup");
    popup.style.display = (popup.style.display === "block") ? "none" : "block";
}
document.addEventListener("DOMContentLoaded", function () {
    const chatBox = document.querySelector(".chat-box");
    const inputField = document.querySelector("input");
    const sendButton = document.querySelector("button");

    // Load chat history from localStorage when page loads
    function loadChatHistory() {
        let chatHistory = JSON.parse(localStorage.getItem("chatHistory")) || [];
        chatHistory.forEach(msg => displayMessage(msg.text, msg.type));
    }

    // Function to display messages
    function displayMessage(text, type) {
        let messageDiv = document.createElement("div");
        messageDiv.classList.add("message", type === "user" ? "user-message" : "bot-message");
        messageDiv.textContent = text;
        chatBox.appendChild(messageDiv);
        chatBox.scrollTop = chatBox.scrollHeight; // Auto-scroll to bottom
    }

    // Function to save chat messages in localStorage
    function saveToHistory(text, type) {
        let chatHistory = JSON.parse(localStorage.getItem("chatHistory")) || [];
        chatHistory.push({ text, type });
        localStorage.setItem("chatHistory", JSON.stringify(chatHistory));
    }

    // Function to show chat history
    function showHistory() {
        let chatHistory = JSON.parse(localStorage.getItem("chatHistory")) || [];
        if (chatHistory.length === 0) {
            displayMessage("No chat history available!", "bot");
        } else {
            chatHistory.forEach(msg => displayMessage(msg.text, msg.type));
        }
    }

    // Event listener for send button
    sendButton.addEventListener("click", function () {
        let userInput = inputField.value.trim();
        if (userInput === "") return;

        displayMessage(userInput, "user");
        saveToHistory(userInput, "user");

        // Check if user wants to see history
        if (userInput.toLowerCase() === "show history") {
            showHistory();
        } else {
            setTimeout(() => {
                let botReply = "Hello! How can I assist you?"; // Default bot response
                displayMessage(botReply, "bot");
                saveToHistory(botReply, "bot");
            }, 500);
        }

        inputField.value = ""; // Clear input field after sending
    });

    // Load chat history on page load
    loadChatHistory();
});
